// [[Rcpp::plugins(cpp17)]]
#include <Rcpp.h>
using namespace Rcpp;

// This version accepts three arguments.
// [[Rcpp::export]]
NumericVector cpp_route_optimizer(NumericMatrix grid, NumericVector vehicle_positions, NumericVector distance) {
  int n = vehicle_positions.size();
  NumericVector optimized_routes(n);
  int center = grid.nrow() / 2;
  for (int i = 0; i < n; i++) {
    optimized_routes[i] = vehicle_positions[i] + (center - vehicle_positions[i]) * 0.1;
  }
  return optimized_routes;
}
