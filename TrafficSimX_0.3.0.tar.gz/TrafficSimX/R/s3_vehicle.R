# Create a vehicle object (S3)
create_vehicle <- function(id, x, y, speed) {
  structure(list(id = id, x = x, y = y, speed = speed), class = "vehicle")
}

# Basic movement: updates x by speed*0.1
move_vehicle <- function(vehicle) {
  vehicle$x <- vehicle$x + vehicle$speed * 0.1
  vehicle
}

# S3 method to move a vehicle to a new position.
move.vehicle <- function(vehicle, new_position) {
  vehicle$x <- new_position[1]
  vehicle$y <- new_position[2]
  return(vehicle)
}
