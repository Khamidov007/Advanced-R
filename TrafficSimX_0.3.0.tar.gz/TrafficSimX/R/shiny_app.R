# Load necessary libraries (including leaflet.extras for addHeatmap)
library(shiny)
library(shinydashboard)
library(leaflet)
library(leaflet.extras)
library(httr)
library(jsonlite)
library(data.table)
library(R6)

ui <- dashboardPage(
  dashboardHeader(title = "TrafficSimX Advanced Simulation"),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Live Heatmap", tabName = "heatmap", icon = icon("map")),
      menuItem("Simulation Settings", tabName = "settings", icon = icon("sliders")),
      menuItem("Traffic Prediction", tabName = "prediction", icon = icon("chart-line")),
      menuItem("Vehicle & Infrastructure", tabName = "details", icon = icon("car"))
    ),
    # Global controls in the sidebar:
    sliderInput("speed", "Vehicle Speed:", min = 30, max = 120, value = 60),
    sliderInput("density", "Traffic Density:", min = 10, max = 100, value = 50),
    selectInput("source", "Source:", choices = c("Warsaw", "Kraków", "Gdańsk")),
    selectInput("destination", "Destination:", choices = c("Gdańsk", "Warsaw", "Kraków")),
    actionButton("optimizeRoute", "Optimize Route")
  ),
  dashboardBody(
    tabItems(
      tabItem(tabName = "heatmap",
              fluidRow(
                box(title = "Live Traffic Heatmap", status = "primary", width = 12,
                    leafletOutput("heatmap", height = 600))
              )
      ),
      tabItem(tabName = "settings",
              fluidRow(
                box(title = "Simulation Settings", width = 12,
                    "Adjust the vehicle speed and traffic density using the sidebar sliders.",
                    br(), br(),
                    "Simulated Traffic Data Summary:",
                    verbatimTextOutput("simulationStats")
                )
              )
      ),
      tabItem(tabName = "prediction",
              fluidRow(
                box(title = "Route Optimization", width = 12,
                    "Select a source and destination and click 'Optimize Route' to simulate route optimization using Rcpp. The optimized traffic predictions will be overlaid on the heatmap.",
                    br(), br(),
                    "Optimized Route Summary:",
                    verbatimTextOutput("routeStats")
                )
              )
      ),
      tabItem(tabName = "details",
              fluidRow(
                box(title = "Vehicle Details", width = 12,
                    tableOutput("vehicleTable")),
                box(title = "Intersection Details", width = 12,
                    tableOutput("intersectionTable")),
                box(title = "Debug Info", width = 12,
                    verbatimTextOutput("debugVehicles"),
                    verbatimTextOutput("debugIntersections"))
              )
      )
    )
  )
)

server <- function(input, output, session) {
  
  # Ensure leaflet.extras is loaded for addHeatmap
  library(leaflet.extras)
  
  # Create an instance of TrafficController; default simulation_time = 100
  sim_controller <- TrafficController$new(simulation_time = 100)
  
  # Wrap the initialization of default objects in an observer so that it
  # only runs once the reactive inputs (such as input$speed) are available.
  observe({
    req(input$speed)  # Wait until input$speed is available
    
    # Initialize default vehicle if none exists:
    if (length(sim_controller$vehicles) == 0) {
      new_vehicle <- create_vehicle(id = 1, x = 52.2297, y = 21.0122, speed = input$speed)
      sim_controller$add_vehicle(new_vehicle)
      print("Default vehicle added:")
      print(sim_controller$vehicles)
    } else {
      print("Vehicles already exist:")
      print(sim_controller$vehicles)
    }
    
    # Initialize default intersections if none exist:
    if (length(sim_controller$intersections) == 0) {
      int1 <- new("Intersection", id = "I1", x = 52.2297, y = 21.0122,
                  traffic_signal = "green", vehicle_density = 10)
      int2 <- new("Intersection", id = "I2", x = 52.2300, y = 21.0150,
                  traffic_signal = "red", vehicle_density = 20)
      sim_controller$intersections <- list(int1, int2)
      print("Default intersections added:")
      print(sim_controller$intersections)
    } else {
      print("Intersections already exist:")
      print(sim_controller$intersections)
    }
  })
  
  # Reactive value for simulation data (mock traffic data)
  simulation_data <- reactiveVal()
  
  # Helper: Generate mock traffic data based on density slider.
  generate_mock_traffic <- function(density) {
    n <- as.numeric(density)
    set.seed(123)
    lat_center <- 52.2297
    lon_center <- 21.0122
    data <- data.frame(
      lat = lat_center + rnorm(n, mean = 0, sd = 0.02),
      lon = lon_center + rnorm(n, mean = 0, sd = 0.02),
      congestion = runif(n, min = 0, max = 100)
    )
    return(data)
  }
  
  # Helper: Simulate loading live congestion data for route optimization.
  load_live_congestion <- function(source, destination) {
    n <- 50
    set.seed(456)
    lat_center <- 52.2297  
    lon_center <- 21.0122
    data <- data.frame(
      lat = lat_center + rnorm(n, mean = 0, sd = 0.02),
      lon = lon_center + rnorm(n, mean = 0, sd = 0.02),
      congestion = runif(n, min = 0, max = 100),
      distance = runif(n, min = 0, max = 10)
    )
    return(data)
  }
  
  # ---------------------------
  # Reactivity for Simulation Settings
  # ---------------------------
  observeEvent(input$density, {
    new_data <- generate_mock_traffic(input$density)
    simulation_data(new_data)
    output$heatmap <- renderLeaflet({
      leaflet(data = new_data) %>%
        addTiles() %>%
        addHeatmap(lng = ~lon, lat = ~lat, intensity = ~congestion,
                   blur = 20, max = 100)
    })
  })
  
  # Update the vehicle speed when the speed slider changes.
  observeEvent(input$speed, {
    if (length(sim_controller$vehicles) > 0) {
      sim_controller$vehicles[[1]]$speed <- input$speed
    } else {
      new_vehicle <- create_vehicle(id = 1, x = 52.2297, y = 21.0122, speed = input$speed)
      sim_controller$add_vehicle(new_vehicle)
    }
  })
  
  # Render simulation statistics summary in Simulation Settings tab.
  output$simulationStats <- renderPrint({
    data <- simulation_data()
    if (is.null(data)) {
      cat("No simulation data available yet.")
    } else {
      stats <- list(
        Mean_Congestion = round(mean(data$congestion), 2),
        Min_Congestion = round(min(data$congestion), 2),
        Max_Congestion = round(max(data$congestion), 2)
      )
      print(stats)
    }
  })
  
  # ---------------------------
  # Reactivity for Traffic Prediction (Route Optimization)
  # ---------------------------
  observeEvent(input$optimizeRoute, {
    congestion_data <- load_live_congestion(input$source, input$destination)
    optimized <- optimize_route(congestion_data$congestion, congestion_data$distance)
    congestion_data$congestion <- optimized
    output$routeStats <- renderPrint({
      stats <- list(
        Mean_Optimized = round(mean(optimized), 2),
        Min_Optimized = round(min(optimized), 2),
        Max_Optimized = round(max(optimized), 2)
      )
      print(stats)
    })
    
    output$heatmap <- renderLeaflet({
      leaflet(data = congestion_data) %>%
        addTiles() %>%
        addHeatmap(lng = ~lon, lat = ~lat, intensity = ~congestion,
                   blur = 20, max = 100)
    })
  })
  
  # --------------------------
  # Render an Initial Heatmap on Launch
  # --------------------------
  output$heatmap <- renderLeaflet({
    initial_data <- generate_mock_traffic(50)
    leaflet(data = initial_data) %>%
      addTiles() %>%
      addHeatmap(lng = ~lon, lat = ~lat, intensity = ~congestion,
                 blur = 20, max = 100)
  })
  
  # ---------------------------
  # Render Vehicle Details Table
  # ---------------------------
  output$vehicleTable <- renderTable({
    vehicles <- sim_controller$vehicles
    if (length(vehicles) == 0) return(data.frame(Message = "No vehicles available"))
    df <- do.call(rbind, lapply(vehicles, function(v) {
      data.frame(ID = v$id, X = v$x, Y = v$y, Speed = v$speed)
    }))
    df
  })
  
  # ---------------------------
  # Render Intersection Details Table
  # ---------------------------
  output$intersectionTable <- renderTable({
    intersections <- sim_controller$intersections
    if (length(intersections) == 0) return(data.frame(Message = "No intersections available"))
    df <- do.call(rbind, lapply(intersections, function(i) {
      data.frame(ID = i@id, X = i@x, Y = i@y,
                 Signal = i@traffic_signal, Density = i@vehicle_density)
    }))
    df
  })
  
  # Debug outputs for vehicles and intersections:
  output$debugVehicles <- renderPrint({
    cat("Number of Vehicles:", length(sim_controller$vehicles), "\n")
    print(sim_controller$vehicles)
  })
  
  output$debugIntersections <- renderPrint({
    cat("Number of Intersections:", length(sim_controller$intersections), "\n")
    print(sim_controller$intersections)
  })
}

run_traffic_simulation_app <- function() {
  shinyApp(ui = ui, server = server)
}
