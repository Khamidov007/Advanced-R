# Define the Intersection S4 Class
setClass("Intersection",
         slots = list(
           id = "character",
           x = "numeric",
           y = "numeric",
           traffic_signal = "character",
           vehicle_density = "numeric"
         )
)

# Custom print method for Intersection objects.
setMethod(
  "show", "Intersection",
  function(object) {
    cat("Intersection ID:", object@id, "\n")
    cat("Signal State:", object@traffic_signal, "\n")
    cat("Vehicle Density:", object@vehicle_density, "\n")
  }
)

# Define the RoadSegment S4 Class.
setClass("RoadSegment",
         slots = list(
           id = "numeric",
           capacity = "numeric",
           current_load = "numeric"
         )
)
