#' Update Positions Vectorised
#'
#' Updates vehicle positions using vectorised addition.
#'
#' @param positions Numeric vector of current positions.
#' @param movement Numeric vector of increments to add to each position.
#' @return A numeric vector containing updated positions.
#' @export
update_positions <- function(positions, movement) {
  new_positions <- positions + movement
  return(new_positions)
}
