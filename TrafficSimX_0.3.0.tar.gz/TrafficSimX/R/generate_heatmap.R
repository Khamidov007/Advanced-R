generate_heatmap <- function(data) {
  leaflet(data) %>%
    addTiles() %>%
    addHeatmap(lng = ~lon, lat = ~lat, intensity = ~congestion, blur = 20, max = 100)
}
