library(httr)
library(jsonlite)
library(data.table)


# TomTom API Key
tomtom_api_key <- "1vzFRMZtKLnIGGrYsaHIJhE34qthSors"

# Function to fetch live traffic data
fetch_live_traffic <- function(city) {
  base_url <- "https://api.tomtom.com/traffic/services/4/flowSegmentData/absolute/10/json"
  coordinates <- switch(city,
                        "Warsaw" = "lat=52.2298&lon=21.0122",
                        "Gdańsk" = "lat=54.3520&lon=18.6466",
                        "Kraków" = "lat=50.0647&lon=19.9450",
                        "Łódź" = "lat=51.7592&lon=19.4550",
                        "Wrocław" = "lat=51.1079&lon=17.0385",
                        "Poznań" = "lat=52.4064&lon=16.9252",
                        "Lublin" = "lat=51.2465&lon=22.5684")
  
  query <- paste0(base_url, "?key=", tomtom_api_key, "&", coordinates)
  
  response <- GET(query)
  if (status_code(response) == 200) {
    return(fromJSON(content(response, "text")))
  } else {
    warning("Failed to fetch traffic data")
    return(NULL)
  }
}

# Function to process API response
process_traffic_data <- function(traffic_json) {
  if (is.null(traffic_json)) return(NULL)
  data <- data.frame(
    lat = traffic_json$coordinates$latitude,
    lon = traffic_json$coordinates$longitude,
    congestion = traffic_json$flowSegmentData$currentSpeed / traffic_json$flowSegmentData$freeFlowSpeed
  )
  return(data)
}

# Function to save traffic data to CSV
save_traffic_csv <- function(data, filename = "traffic_data.csv") {
  fwrite(data, file = filename, append = TRUE)
}

# Function to load historical traffic data
load_historical_data <- function(filename = "traffic_data.csv") {
  if (file.exists(filename)) {
    return(fread(filename))
  } else {
    warning("No historical data found")
    return(NULL)
  }
}
