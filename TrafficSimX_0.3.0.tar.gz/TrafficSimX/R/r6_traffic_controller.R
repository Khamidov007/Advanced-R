TrafficController <- R6::R6Class("TrafficController",
                                 public = list(
                                   vehicles = list(),
                                   intersections = list(),
                                   simulation_time = NULL,
                                   
                                   initialize = function(simulation_time = 100) {  # Default simulation_time = 100
                                     self$simulation_time <- simulation_time
                                   },
                                   
                                   add_vehicle = function(vehicle) {
                                     self$vehicles[[vehicle$id]] <- vehicle
                                   },
                                   
                                   update_traffic = function() {
                                     message("Updating simulation for the current time step …")
                                     for (id in names(self$vehicles)) {
                                       self$vehicles[[id]] <- move_vehicle(self$vehicles[[id]])
                                     }
                                   },
                                   
                                   run_simulation = function() {
                                     for (t in 1:self$simulation_time) {
                                       self$update_traffic()
                                     }
                                   },
                                   
                                   print = function(...) {
                                     cat("TrafficController:", length(self$vehicles), "vehicles; simulation time:", 
                                         self$simulation_time, "\n")
                                   }
                                 )
)
