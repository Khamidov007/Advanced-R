library(Rcpp)
sourceCpp("src/route_optimizer.cpp")

optimize_route <- function(congestion, distance) {
  grid <- matrix(1, nrow = 10, ncol = 10)
  optimized <- cpp_route_optimizer(grid, congestion, distance)
  return(optimized)
}
